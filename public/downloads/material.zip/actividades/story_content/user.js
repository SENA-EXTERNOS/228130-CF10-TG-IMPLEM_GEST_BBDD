function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6XlVJKIb1le":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

